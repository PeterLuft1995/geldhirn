/* Geldhirn – Handy-Optimierungen */
(function () {
  "use strict";
  var isSmall = function () { return window.matchMedia("(max-width: 768px)").matches; };

  function parseDe(str) {
    if (!str) return NaN;
    var s = String(str).replace(/[^0-9,.\-]/g, "");
    if (s.indexOf(",") > -1) s = s.replace(/\./g, "").replace(",", ".");
    else if ((s.match(/\./g) || []).length > 1 || /\.\d{3}$/.test(s)) s = s.replace(/\./g, "");
    return parseFloat(s);
  }

  /* 1. Wert neben dem Schieberegler antippen -> Zahl direkt eintippen (Ziffernblock) */
  function makeEditable(range) {
    var out = document.getElementById(range.id + "-value");
    if (!out || out.dataset.gEdit) return;
    out.dataset.gEdit = "1";
    out.classList.add("g-editable");
    out.setAttribute("role", "button");
    out.setAttribute("tabindex", "0");
    out.setAttribute("title", "Antippen, um den Wert einzugeben");
    function open() {
      if (out.querySelector("input")) return;
      var inp = document.createElement("input");
      inp.type = "text";
      inp.inputMode = "decimal";
      inp.className = "g-edit-input";
      inp.value = String(range.value).replace(".", ",");
      inp.setAttribute("aria-label", "Wert eingeben");
      var old = out.textContent;
      out.textContent = "";
      out.appendChild(inp);
      inp.focus(); inp.select();
      var done = false;
      function commit(apply) {
        if (done) return; done = true;
        var v = parseDe(inp.value);
        if (apply && isFinite(v)) {
          var min = parseFloat(range.min), max = parseFloat(range.max);
          if (isFinite(min) && v < min) v = min;
          if (isFinite(max) && v > max) v = max;
          range.value = v;
          range.dispatchEvent(new Event("input", { bubbles: true }));
          range.dispatchEvent(new Event("change", { bubbles: true }));
        } else {
          out.textContent = old;
        }
        if (out.contains(inp)) out.removeChild(inp);
        if (!out.textContent) out.textContent = old;
      }
      inp.addEventListener("keydown", function (e) {
        if (e.key === "Enter") { e.preventDefault(); commit(true); }
        if (e.key === "Escape") { commit(false); }
      });
      inp.addEventListener("blur", function () { commit(true); });
    }
    out.addEventListener("click", open);
    out.addEventListener("keydown", function (e) { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); open(); } });
  }

  function initEditable() {
    document.querySelectorAll('input[type="range"][id]').forEach(makeEditable);
  }

  /* 2. Nach "Berechnen" auf dem Handy automatisch zum Ergebnis scrollen */
  function initAutoScroll() {
    var targets = document.querySelectorAll('[id$="-results"]');
    var lastAction = 0;
    document.addEventListener("submit", function () { lastAction = Date.now(); }, true);
    document.addEventListener("click", function (e) {
      var b = e.target && e.target.closest ? e.target.closest('button, input[type="submit"]') : null;
      if (b && b.closest("form")) lastAction = Date.now();
    }, true);
    if (!targets.length || !("MutationObserver" in window)) return;
    var obs = new MutationObserver(function (list) {
      list.forEach(function (m) {
        var el = m.target;
        if (m.attributeName === "hidden" && !el.hidden && isSmall() && Date.now() - lastAction < 2000) {
          var r = el.getBoundingClientRect();
          if (r.top > window.innerHeight * 0.6 || r.top < 0) {
            setTimeout(function () { el.scrollIntoView({ behavior: "smooth", block: "start" }); }, 60);
          }
        }
      });
    });
    targets.forEach(function (t) { obs.observe(t, { attributes: true, attributeFilter: ["hidden"] }); });
  }

  /* 3. Ziffernblock für normale Zahlenfelder */
  function initNumericKeyboard() {
    document.querySelectorAll('input[type="number"]').forEach(function (i) {
      if (!i.getAttribute("inputmode")) i.setAttribute("inputmode", "decimal");
    });
  }

  function init() { initEditable(); initAutoScroll(); initNumericKeyboard(); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
